# spectral_color

> shared primitive. visible light 380–700nm mapped through CIE 1931 color-matching functions to accurate sRGB. the difference between real physics and cartoon rainbow.

## what it does

Computes `wavelengthToRGB(λ)` and `spectrumToRGB(S(λ))` using the CIE 1931 2° standard observer. Every spectral generator in the Color Lab consumes this.

## the math

**CIE 1931 CMF fits** (improved gaussian approximations):

```
x̄(λ) = 1.056·exp(-0.5·((λ-599.8)/37.9)²) + 0.362·exp(-0.5·((λ-442.0)/16.0)²) + 0.065·exp(-0.5·((λ-501.1)/28.3)²)
ȳ(λ) = 0.821·exp(-0.5·((λ-568.8)/46.9)²) + 0.286·exp(-0.5·((λ-530.9)/20.3)²)
z̄(λ) = 1.026·exp(-0.5·((λ-473.1)/21.3)²) + 0.094·exp(-0.5·((λ-570.1)/132.7)²) + 0.305·exp(-0.5·((λ-604.2)/23.4)²)
```

**XYZ → linear sRGB** (D65):

```
[  3.2406  -1.5372  -0.4986 ]
[ -0.9689   1.8758   0.0415 ]
[  0.0557  -0.2040   1.0570 ]
```

**Gamma:** V ≤ 0.0031308 → 12.92·V; else → 1.055·V^(1/2.4) - 0.055

**Full spectrum:** X = Σ S(λ)·x̄(λ), Y = Σ S(λ)·ȳ(λ), Z = Σ S(λ)·z̄(λ)

## files

- `src/js/spectral-color.js` — LUT generation, `wavelengthToRGB()`, `spectrumToRGB()`
- `src/shaders/spectral-color.glsl` — same functions, GPU-side
- `docs/cie-1931-reference.md` — tabulated CMF values
- `docs/visual-targets.md` — what the output should look like

## usage

```js
import { wavelengthToRGB, spectrumToRGB, buildSpectralLUT } from './src/js/spectral-color.js';
const lut = buildSpectralLUT(256); // 256px 1D texture
const rgb = wavelengthToRGB(550);  // green
```

## ecosystem

**Consumed by:** `prism_dispersion`, `rainbow_optics`, `diffraction_grating`, `opal_play_of_color`, `birefringence`  
**Consumes:** none (self-contained)  
**Pairs with:** any spectral generator

## references

- CIE 1931 2° Standard Observer, ISO/CIE 10527
- Wyszecki & Stiles, *Color Science* (2nd ed.), pp. 145–167
- Bruton, "Approximate RGB values for Visible Wavelengths" (improved fits)
