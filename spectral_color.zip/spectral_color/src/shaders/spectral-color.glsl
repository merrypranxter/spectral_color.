float cmfX(float l) {
  return 1.056*exp(-0.5*pow((l-599.8)/37.9,2.0))
       + 0.362*exp(-0.5*pow((l-442.0)/16.0,2.0))
       + 0.065*exp(-0.5*pow((l-501.1)/28.3,2.0));
}
float cmfY(float l) {
  return 0.821*exp(-0.5*pow((l-568.8)/46.9,2.0))
       + 0.286*exp(-0.5*pow((l-530.9)/20.3,2.0));
}
float cmfZ(float l) {
  return 1.026*exp(-0.5*pow((l-473.1)/21.3,2.0))
       + 0.094*exp(-0.5*pow((l-570.1)/132.7,2.0))
       + 0.305*exp(-0.5*pow((l-604.2)/23.4,2.0));
}

vec3 xyzToLinearRgb(float x, float y, float z) {
  return vec3(
     3.2406*x - 1.5372*y - 0.4986*z,
    -0.9689*x + 1.8758*y + 0.0415*z,
     0.0557*x - 0.2040*y + 1.0570*z
  );
}

float srgbGamma(float v) {
  return v <= 0.0031308 ? 12.92*v : 1.055*pow(v, 1.0/2.4) - 0.055;
}

vec3 wavelengthToRGB(float lambda) {
  float X = cmfX(lambda), Y = cmfY(lambda), Z = cmfZ(lambda);
  vec3 rgb = xyzToLinearRgb(X, Y, Z);
  float maxY = cmfY(555.0);
  float scale = maxY / max(Y, 0.0001);
  rgb *= scale;
  float maxc = max(max(rgb.r, rgb.g), max(rgb.b, 1.0));
  rgb = vec3(srgbGamma(clamp(rgb.r/maxc, 0.0, 1.0)),
             srgbGamma(clamp(rgb.g/maxc, 0.0, 1.0)),
             srgbGamma(clamp(rgb.b/maxc, 0.0, 1.0)));
  return rgb;
}

uniform sampler2D u_spectralLUT;
vec3 wavelengthToRGB_LUT(float lambda) {
  float u = (lambda - 380.0) / 320.0;
  return texture2D(u_spectralLUT, vec2(u, 0.5)).rgb;
}
