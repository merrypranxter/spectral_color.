const CMF_X = [
  {a:1.056, m:599.8, s:37.9},
  {a:0.362, m:442.0, s:16.0},
  {a:0.065, m:501.1, s:28.3}
];
const CMF_Y = [
  {a:0.821, m:568.8, s:46.9},
  {a:0.286, m:530.9, s:20.3}
];
const CMF_Z = [
  {a:1.026, m:473.1, s:21.3},
  {a:0.094, m:570.1, s:132.7},
  {a:0.305, m:604.2, s:23.4}
];

function gauss(x, a, m, s) {
  return a * Math.exp(-0.5 * Math.pow((x - m) / s, 2));
}

export function cmfX(lambda) { return CMF_X.reduce((sum, g) => sum + gauss(lambda, g.a, g.m, g.s), 0); }
export function cmfY(lambda) { return CMF_Y.reduce((sum, g) => sum + gauss(lambda, g.a, g.m, g.s), 0); }
export function cmfZ(lambda) { return CMF_Z.reduce((sum, g) => sum + gauss(lambda, g.a, g.m, g.s), 0); }

const M = [
  [ 3.2406, -1.5372, -0.4986],
  [-0.9689,  1.8758,  0.0415],
  [ 0.0557, -0.2040,  1.0570]
];

function xyzToLinearRgb(x, y, z) {
  return [
    M[0][0]*x + M[0][1]*y + M[0][2]*z,
    M[1][0]*x + M[1][1]*y + M[1][2]*z,
    M[2][0]*x + M[2][1]*y + M[2][2]*z
  ];
}

function srgbGamma(v) {
  if (v <= 0.0031308) return 12.92 * v;
  return 1.055 * Math.pow(v, 1/2.4) - 0.055;
}

function clamp01(v) { return Math.max(0, Math.min(1, v)); }

export function wavelengthToRGB(lambda) {
  const X = cmfX(lambda), Y = cmfY(lambda), Z = cmfZ(lambda);
  let [r, g, b] = xyzToLinearRgb(X, Y, Z);
  const maxY = cmfY(555);
  const scale = maxY / Math.max(Y, 0.0001);
  r *= scale; g *= scale; b *= scale;
  const maxc = Math.max(r, g, b, 1);
  r = srgbGamma(clamp01(r / maxc));
  g = srgbGamma(clamp01(g / maxc));
  b = srgbGamma(clamp01(b / maxc));
  return [r, g, b];
}

export function spectrumToRGB(spectrum) {
  let X = 0, Y = 0, Z = 0, totalW = 0;
  for (const s of spectrum) {
    const w = s.intensity || 1;
    X += cmfX(s.wavelength) * w;
    Y += cmfY(s.wavelength) * w;
    Z += cmfZ(s.wavelength) * w;
    totalW += w;
  }
  if (totalW > 0) { X /= totalW; Y /= totalW; Z /= totalW; }
  let [r, g, b] = xyzToLinearRgb(X, Y, Z);
  const maxc = Math.max(r, g, b, 1);
  r = srgbGamma(clamp01(r / maxc));
  g = srgbGamma(clamp01(g / maxc));
  b = srgbGamma(clamp01(b / maxc));
  return [r, g, b];
}

export function buildSpectralLUT(size = 256) {
  const data = new Uint8Array(size * 4);
  for (let i = 0; i < size; i++) {
    const lambda = 380 + (i / (size - 1)) * 320;
    const [r, g, b] = wavelengthToRGB(lambda);
    data[i*4]   = Math.round(r * 255);
    data[i*4+1] = Math.round(g * 255);
    data[i*4+2] = Math.round(b * 255);
    data[i*4+3] = 255;
  }
  return data;
}
