import { buildSpectralLUT, wavelengthToRGB } from './spectral-color.js';

const W = 512, H = 256;
const canvas = document.getElementById('spectrum');
canvas.width = W; canvas.height = H;
const ctx = canvas.getContext('2d');
const img = ctx.createImageData(W, H);
const lut = buildSpectralLUT(256);

for (let y = 0; y < H; y++) {
  for (let x = 0; x < W; x++) {
    const lambda = 380 + (x / (W-1)) * 320;
    const [r,g,b] = wavelengthToRGB(lambda);
    const i = (y * W + x) * 4;
    img.data[i]   = Math.round(r * 255);
    img.data[i+1] = Math.round(g * 255);
    img.data[i+2] = Math.round(b * 255);
    img.data[i+3] = 255;
  }
}
ctx.putImageData(img, 0, 0);

const bar = document.getElementById('bar');
bar.width = 256; bar.height = 1;
const bctx = bar.getContext('2d');
const bimg = bctx.createImageData(256, 1);
for (let i = 0; i < 256; i++) {
  const r = lut[i*4], g = lut[i*4+1], b = lut[i*4+2];
  bimg.data[i*4] = r; bimg.data[i*4+1] = g; bimg.data[i*4+2] = b; bimg.data[i*4+3] = 255;
}
bctx.putImageData(bimg, 0, 0);
bctx.drawImage(bar, 0, 0, 256, 1, 0, 0, bar.clientWidth, 40);
